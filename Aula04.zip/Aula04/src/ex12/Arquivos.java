package ex12;

public class Arquivos {
	private double tamanhoArquivo;
	
	public Arquivos(double tamanhoArquivo) {
		this.tamanhoArquivo = tamanhoArquivo;
	}

	public double getTamanhoArquivo() {
		return tamanhoArquivo;
	}

	public void setTamanhoArquivo(double tamanhoArquivo) {
		this.tamanhoArquivo = tamanhoArquivo;
	}
}
