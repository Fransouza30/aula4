package ex8;

public interface FormaGeometrica {
	public double calcularArea(double x, double y);
	public double calcularArea(double x);
	public double calcularPerimetro(double x, double y);
	public double calcularPerimetro(double x);
}
