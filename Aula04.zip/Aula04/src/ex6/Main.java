package ex6;

public class Main {

	public static void main(String[] args) {
		ContaBancaria cb = new ContaBancaria(2, 24000);
		cb.sacar(25000);

	}

}
