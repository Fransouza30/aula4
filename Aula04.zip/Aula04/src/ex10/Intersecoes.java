package ex10;

public class Intersecoes {

}
