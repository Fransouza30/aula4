package ex5;

public abstract class Poligono {
	public abstract double area(double x, double y);
	public abstract double area(double x);

}
