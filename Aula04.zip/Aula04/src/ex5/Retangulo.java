package ex5;

public class Retangulo extends Poligono {

	@Override
	public double area(double x, double y) {
		return x * y;
	}

	@Override
	public double area(double x) {
		// TODO Auto-generated method stub
		return 0;
	}
}
